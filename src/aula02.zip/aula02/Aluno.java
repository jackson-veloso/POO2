package aula02;

public class Aluno extends Pessoa {
    public Aluno(String nome) {
        super.setNome(nome);
    }
}
