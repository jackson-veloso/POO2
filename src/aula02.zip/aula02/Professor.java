package aula02;

public class Professor extends Pessoa {
    public Professor(String nome) {
        super.setNome(nome);
    }
}
