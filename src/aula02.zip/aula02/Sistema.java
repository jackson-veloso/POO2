package aula02;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class Sistema {
    public static void main(String[] args) {
        Turma turma = new Turma();

        cadastrarAluno(new Aluno("Jackson"),turma);
        cadastrarAluno(new Aluno("Jorge"),turma);
        cadastrarAluno(new Aluno("Livia"),turma);

        cadastrarProfessor(new Professor("Kadu"),turma);

        System.out.printf("Professor: %s\n",turma.getProfessor().getNome());
        for (Aluno aluno : turma.getAlunos()) {
            System.out.println("Aluno: " + aluno.getNome());
        }


    }

    public static void cadastrarAluno(Aluno aluno, Turma turma){
        turma.getAlunos().add(aluno);
    }

    public static void cadastrarProfessor(Professor professor, Turma turma) {
        turma.setProfessor(professor);
    }
}
